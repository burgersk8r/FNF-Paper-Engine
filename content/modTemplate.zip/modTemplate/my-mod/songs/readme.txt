==  SONGS  ==
Put your songs here, it should look like this:

mods/songs/your-song-name-here/audio/
---- ./Inst.ogg
---- ./Voices.ogg

Alternatively, it can also look like this if you have separate voice files:

mods/songs/your-song-name-here/audio/
---- ./Inst.ogg
---- ./Voices-Opponent.ogg
---- ./Voices-Player.ogg

== CHARTS ==
Put your charts here, it should look something like this:

mods/songs/your-song-name/charts/
---- ./your-song-name-easy.json
---- ./your-song-name.json
---- ./your-song-name-hard.json
---- ./events.json
---- ./preload.json

== SONG SPECIFIC SCRIPTS ==
Put your lua or hx scripts here, it should look something like this:

mods/songs/your-song-name/scripts/
---- ./your script here.lua
---- ./YourScriptHere.hx