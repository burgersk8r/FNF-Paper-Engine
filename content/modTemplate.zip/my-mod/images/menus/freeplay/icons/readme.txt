Put your freeplay icons here!

Freeplay icons should be formated like this:
freeplay/icons/[character name]/icon.png

Icon size must be 150x150!